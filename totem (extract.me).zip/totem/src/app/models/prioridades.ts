export enum Prioridades {
  SG = "SG",
  SP = "SP",
  SE = "SE"
}
